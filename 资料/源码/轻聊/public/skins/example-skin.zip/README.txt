完整 ZIP 皮肤示例（也可只上传 example-skin.css，更简单）

目录：
  manifest.json  皮肤信息（不写也会自动生成）
  skin.css       样式，浅色写 :root，深色写 :root[data-theme="dark"]
  preview.svg    列表里显示的预览图（不写也会自动生成）

改法：
1. 把 manifest.json 里的 id 改成英文小写+数字+横线（如 my-pink）
2. 改 name / description 为你自己的名字和介绍
3. 在 skin.css 里改颜色变量，深浅两套都要写
4. 打包成 ZIP 上传；或直接用 example-skin.css 单文件上传

上传后默认是私密皮肤，只有自己能看到；在皮肤列表点「设公开」即可分享。
