皮肤示例包 · 轻聊标准版
================================
1. 把本 ZIP 直接上传到「主页 → 皮肤 → 上传皮肤 ZIP」即可看到效果。
2. 复制这个目录改造你自己的皮肤：
   - manifest.json：改 id（小写字母/数字/横线）、name、description、author、version
   - skin.css：覆盖 CSS 变量即可换色；要改结构用 html[data-skin="你的id"] 作用域
   - preview.svg / .png：预览图（可选）
3. 规则：ZIP ≤ 3MB，解压后 ≤ 10MB；只允许 css/png/jpg/gif/webp/svg/字体/json/txt。
4. 上传后默认私密（只有你自己能看见），在皮肤列表点「设公开」即可给大家用。
